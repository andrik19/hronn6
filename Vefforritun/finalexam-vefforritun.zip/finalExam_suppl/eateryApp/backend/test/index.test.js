//Importing the application to test
let server = require('../index');

//These are the actual modules we use
let chai = require('chai');
let should = chai.should();
let chaiHttp = require('chai-http');
chai.use(chaiHttp);

let apiUrl = "http://localhost:3000";

describe('Eatery endpoint tests', () => {
    it("DELETE /api/v1/eateries/:eatId success", function (done) {
        chai.request(apiUrl)
            .delete('/api/v1/eateries/1')
            .end((err, res) => {
                chai.expect(res).to.have.status(200);
                chai.expect(res).to.be.json;

                chai.expect(res.body).to.have.property("id").eql(1)
                chai.expect(res.body).to.have.property("name").eql("Tjörnin")
                chai.expect(res.body).to.have.property("description").eql("Best goose in town")
                chai.expect(res.body).to.have.property("location").eql({lat: 64.145928, lng: -21.940736})
                chai.expect(res.body).to.have.property("logo").eql("https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Tj%C3%B6rnin%2C_Reykjavik.jpg/320px-Tj%C3%B6rnin%2C_Reykjavik.jpg")

                chai.expect(Object.keys(res.body).length).to.be.eql(5)
                chai.expect(res.body).to.be.a('object')
                done();

        })
    });
});

