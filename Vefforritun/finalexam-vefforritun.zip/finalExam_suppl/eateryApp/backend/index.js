const express = require('express');
const cors = require('cors');

const app = express();
const port = 3000;

const prefix = "/api";
const version = "/v1";

app.use(express.json());
app.use(cors());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

let eateries = [{ id: 1, name: "Tjörnin", description: "Best goose in town", location: {lat: 64.145928, lng: -21.940736}, logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Tj%C3%B6rnin%2C_Reykjavik.jpg/320px-Tj%C3%B6rnin%2C_Reykjavik.jpg" }, 
            { id: 3, name: "Elliðaárdalur", description: "Tasty rabbit.", location: {lat: 64.1150903, lng: -21.8417715}, logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Ellirardalur10.JPG/320px-Ellirardalur10.JPG" }];

app.get(prefix + version + '/eateries', (req, res) => {

    if (req.query.limit !== undefined && req.query.start !== undefined && isNaN(req.query.limit) === false && isNaN(req.query.start) === false) {
        var startArray = retStart(req.query.start)
        var retArray = []
        for (let i=0; i<req.query.limit; i++) {
            if (i<=startArray.length-1) {
                retArray.push(startArray[i])
            }
        }
    }

    else if (req.query.limit !== undefined && isNaN(req.query.limit) === false && req.query.limit > 0) { 
        var retArray = retLimit(req.query.limit)
    }

    else if (req.query.start !== undefined && isNaN(req.query.start) === false && req.query.start > 0) { 
        var startArray = retStart(req.query.start)
        var retArray = []
        for (let i=0; i<10; i++) {
            if (i<=startArray.length-1) {
                retArray.push(startArray[i])
            }
        }
    }

    else {
        var retArray = retLimit()
    }

    return res.status(200).json(retArray);
});

function retLimit(limit=10) {
    var retArray = [];
    for (let i=0; i<limit; i++) {
        if (i<=eateries.length-1) {
            retArray.push(eateries[i])
        }
    }
    return retArray
}

function retStart(start) {
    var retArray = [];
    for (let i=0; i<eateries.length; i++) {
        if (i>start-1) {
            retArray.push(eateries[i])
        }
    }
    return retArray
}

app.delete(prefix + version + '/eateries/:eatId', (req, res) => {
    for (let i = 0; i < eateries.length; i++) {
        if (eateries[i].id == req.params.eatId) {
            res.status(200).json(eateries.splice(i, 1)[0]);
            return;
        }
    }
    res.status(404).json({ 'message': "Eatery with id " + req.params.eatId + " does not exist." });
});


let nextId = 100;
app.post(prefix + version + '/eateries', (req, res) => {
    if (req.body === undefined || req.body.name === undefined || req.body.description === undefined || req.body.location === undefined || req.body.logo === undefined) {
        return res.status(400).json({'message': 'Name, description, location and logo must be defined.'});
    }

    if (req.body.name === "" || req.body.logo === "") {
        return res.status(400).json({'message': 'Name and logo can not be empty strings.'});
    }

    for (let i=0; i<eateries.length; i++) {
        if (req.body.name == eateries[i].name) {
            return res.status(400).json({'message': 'Name has to be unique.'});
        }
    }

    if (typeof req.body.location !== 'object' || typeof req.body.location.lat !== 'number' || typeof req.body.location.lng !== 'number' || req.body.location.lat > 90 || req.body.location.lat < -90 ||req.body.location.lat > 180 || req.body.location.lat < -180) {
        return res.status(400).json({'message': 'Location must be an object with the numbers 90>=lat>=-90 and 180>=long>=-180'});
    }

    var newEatery = {'id': nextId, 'name': req.body.name, 'description': req.body.description, 'location': req.body.location, 'logo': req.body.logo}
    eateries.push(newEatery);
    nextId++;
    return res.status(201).json(newEatery);
})



//Default: Not supported
app.use('*', (req, res) => {
    res.status(405).send('Operation not supported.');
});

app.listen(port, () => {
    console.log('Eatery app listening on port ' + port);
});