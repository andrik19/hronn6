//##################
//This code is for rendering the map and for drawing markers. You do not need to modify it.
//##################
let map;
let currentMapMarker;
function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 64.1459303, lng: -21.94293},
    zoom: 15,
  });
}
function setCenter (targetLat, targetLng, descriptor) {
  map.setCenter({lat: targetLat, lng: targetLng});
  if (currentMapMarker !== undefined) {
    currentMapMarker.setMap(null);
  }
  currentMapMarker = new google.maps.Marker({
    position: {lat: targetLat, lng: targetLng},
    map: map
  });
  let infowindow = new google.maps.InfoWindow({content: descriptor});
  infowindow.open(map,currentMapMarker);
}
//##################
//Map code finished.
//##################


function getAllEateries() {
  let eatList = document.getElementById("eatList");
  eatList.innerHTML='';

  let url = 'http://localhost:3000/api/v1/eateries';

  axios.get(url)
      .then(function (response) {
          if (response.data !== null) {
              for (let i = 0; i < response.data.length; i++) {
                let eatItem = document.createElement("p");
                let eatHeader = document.createElement("h3");
                eatHeader.textContent = "Eatery " + (i+1);
                let eatText = document.createTextNode("Name: " + response.data[i].name + "\n");
                eatItem.appendChild(eatHeader);
                eatItem.appendChild(eatText);
                eatList.appendChild(eatItem);

                eatItem.classList.add("eatery")

                var showButton = document.createElement("BUTTON")
                var btntext = document.createTextNode("Show Information")
                showButton.appendChild(btntext)

                var lineBreak = document.createElement("p");
                lineBreak.classList.add("button")
                eatItem.appendChild(lineBreak) // space between button and text
                
                eatItem.appendChild(showButton);
      
                showButton.addEventListener('click', function(e) {
                  var name = response.data[i].name
                  var description = response.data[i].description
                  var logo = response.data[i].logo
                  dispDiv(name, description, logo)

                  var lat = response.data[i].location.lat
                  var long = response.data[i].location.lng
                  setCenter(lat, long, name)
                })


              }
          }
      })
      .catch(function (error) {
          console.log(error);
      });

}

getAllEateries();

function dispDiv(eatName,eatDesc, eatLogo) {

  var textDiv = document.getElementById("textDescription");
  textDiv.innerHTML='';

  var name = document.createElement("p")
  var nameText = document.createTextNode(eatName)
  name.appendChild(nameText)
  textDiv.appendChild(name)

  var desc = document.createElement("p")
  var descText = document.createTextNode(eatDesc)
  desc.appendChild(descText)
  textDiv.appendChild(desc)

  var logo = document.createElement("img")
  logo.src = eatLogo
  textDiv.appendChild(logo)
}
